-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.48-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema postal
--

CREATE DATABASE IF NOT EXISTS postal;
USE postal;

--
-- Definition of table `applicant`
--

DROP TABLE IF EXISTS `applicant`;
CREATE TABLE `applicant` (
  `applicant_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` varchar(45) NOT NULL DEFAULT '0',
  `branch_id` int(10) unsigned DEFAULT NULL,
  `city_id` int(10) unsigned DEFAULT NULL,
  `firstname` varchar(45) DEFAULT NULL,
  `middlename` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `doorno` varchar(45) DEFAULT NULL,
  `street` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `pincode` varchar(45) DEFAULT NULL,
  `phoneno` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `deposit` varchar(45) DEFAULT NULL,
  `photo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`applicant_id`,`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicant`
--

/*!40000 ALTER TABLE `applicant` DISABLE KEYS */;
INSERT INTO `applicant` (`applicant_id`,`account_id`,`branch_id`,`city_id`,`firstname`,`middlename`,`lastname`,`gender`,`doorno`,`street`,`state`,`pincode`,`phoneno`,`email`,`status`,`deposit`,`photo`) VALUES 
 (5,'110',10,9,'Akash','C','K','male','1234','12th street','Kerala','671551','9074921876','akash@gmail.com','approved','4000','977204.jpg'),
 (6,'111',11,14,'Abhishek','L','D','male','6699','23th street','Kerala','671552','9074895414','abhishek@gmail.com','rejected','4000','IMG_2677.HEIC'),
 (7,'112',10,10,'Karthikeya','S','K','male','1234','23th street','Karnataka','671552','1245879630','karthikeya@gmail.com','approved','3000','Screenshot 2023-05-07 233827.png'),
 (8,'117',10,12,'Latheesh','r','y','male','75','123th Street','Kerala','671557','1265987631','latheesh@gmail.com','approved','5000','Screenshot 2023-06-05 223429.png'),
 (9,'999',10,15,'Akhilesh ','i','k','male','45','09th Street','Karnataka','564879','9074925612','akhilesh@gmail.com','approved','450','IMG_20201010_130844.jpg');
/*!40000 ALTER TABLE `applicant` ENABLE KEYS */;


--
-- Definition of table `branch`
--

DROP TABLE IF EXISTS `branch`;
CREATE TABLE `branch` (
  `branch_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(45) NOT NULL,
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` (`branch_id`,`branch_name`) VALUES 
 (10,'Karnataka Branch'),
 (11,'Bantwal branch'),
 (12,'Sumangala branch'),
 (14,'Kuriyala Branch'),
 (16,'Mallur Branch'),
 (17,'Chelur Branch'),
 (18,'Thumbe Branch'),
 (19,'Boliyar Branch'),
 (20,'Vamanjoor');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;


--
-- Definition of table `city`
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `city_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` int(10) unsigned DEFAULT NULL,
  `cityname` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` (`city_id`,`state_id`,`cityname`) VALUES 
 (9,2,'Mangalore'),
 (10,6,'Ahmedabad'),
 (11,5,'Chennai'),
 (12,4,'Margao'),
 (13,8,'Senapatti'),
 (14,9,'Vijayawada'),
 (15,7,'Patna'),
 (16,2,'Puttur');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;


--
-- Definition of table `discharge`
--

DROP TABLE IF EXISTS `discharge`;
CREATE TABLE `discharge` (
  `slno` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` int(10) unsigned DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `amount` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discharge`
--

/*!40000 ALTER TABLE `discharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `discharge` ENABLE KEYS */;


--
-- Definition of table `document`
--

DROP TABLE IF EXISTS `document`;
CREATE TABLE `document` (
  `document_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) DEFAULT NULL,
  `adharcard` varchar(45) DEFAULT NULL,
  `photo` varchar(45) DEFAULT NULL,
  `pancard` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `document`
--

/*!40000 ALTER TABLE `document` DISABLE KEYS */;
INSERT INTO `document` (`document_id`,`account_id`,`adharcard`,`photo`,`pancard`,`status`) VALUES 
 (1,'0','WIN_20230602_11_42_45_Pro.jpg','WIN_20230602_11_42_49_Pro.jpg','WIN_20230602_11_42_55_Pro.jpg','pending');
/*!40000 ALTER TABLE `document` ENABLE KEYS */;


--
-- Definition of table `fixed`
--

DROP TABLE IF EXISTS `fixed`;
CREATE TABLE `fixed` (
  `fixed_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` varchar(20) DEFAULT NULL,
  `payment_mode` varchar(45) DEFAULT NULL,
  `cheque_no` int(10) unsigned DEFAULT NULL,
  `bank_name` varchar(15) DEFAULT NULL,
  `branch_id` varchar(15) DEFAULT NULL,
  `ifsc` varchar(45) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `amount` int(10) unsigned DEFAULT NULL,
  `transaction_year` varchar(45) DEFAULT NULL,
  `interest` varchar(45) DEFAULT NULL,
  `deposited_by` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`fixed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fixed`
--

/*!40000 ALTER TABLE `fixed` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed` ENABLE KEYS */;


--
-- Definition of table `insurance_transaction`
--

DROP TABLE IF EXISTS `insurance_transaction`;
CREATE TABLE `insurance_transaction` (
  `transaction_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` varchar(45) DEFAULT NULL,
  `policy_no` varchar(45) DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `transaction_month` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insurance_transaction`
--

/*!40000 ALTER TABLE `insurance_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `insurance_transaction` ENABLE KEYS */;


--
-- Definition of table `new_saving`
--

DROP TABLE IF EXISTS `new_saving`;
CREATE TABLE `new_saving` (
  `saving_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` varchar(15) DEFAULT NULL,
  `payment_mode` varchar(45) DEFAULT NULL,
  `cheque_no` varchar(45) DEFAULT NULL,
  `bank_name` varchar(45) DEFAULT NULL,
  `branch_id` varchar(45) DEFAULT NULL,
  `ifsc` varchar(45) DEFAULT NULL,
  `amount` varchar(20) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`saving_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `new_saving`
--

/*!40000 ALTER TABLE `new_saving` DISABLE KEYS */;
INSERT INTO `new_saving` (`saving_id`,`account_no`,`payment_mode`,`cheque_no`,`bank_name`,`branch_id`,`ifsc`,`amount`,`date`) VALUES 
 (1,'110','cash','','','-- Select Any --','','5000','2023-06-09 00:00:00'),
 (2,'112','cash','','','-- Select Any --','','25000','2023-06-09 00:00:00');
/*!40000 ALTER TABLE `new_saving` ENABLE KEYS */;


--
-- Definition of table `policy_insurance`
--

DROP TABLE IF EXISTS `policy_insurance`;
CREATE TABLE `policy_insurance` (
  `insurance_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` varchar(45) DEFAULT NULL,
  `branch_id` varchar(45) DEFAULT NULL,
  `policy_no` varchar(45) DEFAULT NULL,
  `date_of_receipt` datetime DEFAULT NULL,
  `maturity` varchar(45) DEFAULT NULL,
  `deposit` varchar(45) DEFAULT NULL,
  `interest` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`insurance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `policy_insurance`
--

/*!40000 ALTER TABLE `policy_insurance` DISABLE KEYS */;
INSERT INTO `policy_insurance` (`insurance_id`,`account_no`,`branch_id`,`policy_no`,`date_of_receipt`,`maturity`,`deposit`,`interest`) VALUES 
 (1,'110','10','111222333','2023-06-08 00:00:00','20 ','5000','8'),
 (2,'111','10','111222777','2023-06-08 00:00:00','20 ','3000','7');
/*!40000 ALTER TABLE `policy_insurance` ENABLE KEYS */;


--
-- Definition of table `provident`
--

DROP TABLE IF EXISTS `provident`;
CREATE TABLE `provident` (
  `provident_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` varchar(20) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `salary` int(10) unsigned DEFAULT NULL,
  `amount` int(10) unsigned DEFAULT NULL,
  `deposited_by` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`provident_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provident`
--

/*!40000 ALTER TABLE `provident` DISABLE KEYS */;
/*!40000 ALTER TABLE `provident` ENABLE KEYS */;


--
-- Definition of table `registration`
--

DROP TABLE IF EXISTS `registration`;
CREATE TABLE `registration` (
  `registrationid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phoneno` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `usertype` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`registrationid`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

/*!40000 ALTER TABLE `registration` DISABLE KEYS */;
INSERT INTO `registration` (`registrationid`,`name`,`email`,`phoneno`,`password`,`usertype`) VALUES 
 (33,'Navnith','navnith@gmail.com','9074903839','1230','Admin'),
 (34,'Abhay','abhay@gmail.com','9074959421','1230','Staff'),
 (35,'Akash','akash@gmail.com','9074921876','1230','Account Holder'),
 (36,'Abhishek','abhishek@gmail.com','9074925612','1230','Account Holder'),
 (37,'Karthikeya','karthikeya@gmail.com','1245879630','1230','Account Holder'),
 (38,'Latheesh','latheesh@gmail.com','1265987631','1230','Account Holder'),
 (39,'Akhilesh','Akhilesh@gmail.com','1246325987','1230','Account Holder');
/*!40000 ALTER TABLE `registration` ENABLE KEYS */;


--
-- Definition of table `saving`
--

DROP TABLE IF EXISTS `saving`;
CREATE TABLE `saving` (
  `saving_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` int(10) unsigned DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL,
  `cheque_no` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`saving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saving`
--

/*!40000 ALTER TABLE `saving` DISABLE KEYS */;
/*!40000 ALTER TABLE `saving` ENABLE KEYS */;


--
-- Definition of table `state`
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE `state` (
  `state_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `state_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` (`state_id`,`state_name`) VALUES 
 (2,'Karnataka'),
 (3,'Madhya Pradesh'),
 (4,'Tamil Nadu'),
 (5,'Maharastra'),
 (6,'West Bengal'),
 (7,'Assam'),
 (8,'Bihaar'),
 (9,'Goa'),
 (10,'Kerala'),
 (11,'Punjab'),
 (12,'Rajastan'),
 (13,'Jammu');
/*!40000 ALTER TABLE `state` ENABLE KEYS */;


--
-- Definition of table `withdrawal`
--

DROP TABLE IF EXISTS `withdrawal`;
CREATE TABLE `withdrawal` (
  `withdrawal_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` varchar(20) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `amount` int(10) unsigned DEFAULT NULL,
  `deposited_by` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`withdrawal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `withdrawal`
--

/*!40000 ALTER TABLE `withdrawal` DISABLE KEYS */;
INSERT INTO `withdrawal` (`withdrawal_id`,`account_no`,`date`,`amount`,`deposited_by`) VALUES 
 (1,'110','2023-06-09 00:00:00',1000,'abhay@gmail.com'),
 (2,'112','2023-06-09 00:00:00',1000,'abhay@gmail.com'),
 (3,'999','2023-06-09 00:00:00',500,'abhay@gmail.com'),
 (4,'999','2023-06-09 00:00:00',50,'abhay@gmail.com'),
 (5,'112','2023-06-09 00:00:00',1000,'abhay@gmail.com');
/*!40000 ALTER TABLE `withdrawal` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
